# Scalper V2 vs current scalper

NIFTY · 18 trading days (2026-09-11 → 2026-10-08) · 1 lot · same 1-min data, option model, fills and engine for every test.

## 1. Headline — every test under all three fill models

|                                           |   trades |   win_rate |    net |     pf |   avg_trade |   expectancy_R |   max_dd |   worst_day |   charges |
|:------------------------------------------|---------:|-----------:|-------:|-------:|------------:|---------------:|---------:|------------:|----------:|
| A current scalper · charges only          |       81 |       48.1 |  -1076 |   0.92 |         -13 |         -0.041 |    -5766 |       -1155 |      5699 |
| A current scalper · base                  |       79 |       44.3 | -10051 |   0.43 |        -127 |         -0.391 |   -11708 |       -1339 |      5541 |
| A current scalper · conservative          |       62 |       17.7 | -12002 |   0.31 |        -193 |         -0.596 |   -13316 |       -1461 |      4318 |
| B V2 strict (spec-literal) · charges only |        1 |      100   |    671 | inf    |         671 |          1.79  |        0 |         671 |        79 |
| B V2 strict (spec-literal) · base         |        1 |      100   |     37 | inf    |          37 |          0.099 |        0 |          37 |        78 |
| B V2 strict (spec-literal) · conservative |        1 |        0   |    -15 |   0    |         -15 |         -0.039 |      -15 |         -15 |        78 |
| C V2 no agents · charges only             |       10 |       50   |    804 |   1.48 |          80 |          0.224 |     -887 |        -808 |       764 |
| C V2 no agents · base                     |        8 |       37.5 |  -1405 |   0.32 |        -175 |         -0.53  |    -1405 |        -942 |       594 |
| C V2 no agents · conservative             |        6 |       16.7 |   -800 |   0.41 |        -133 |         -0.387 |     -800 |        -534 |       442 |
| D V2 + agents (crude) · charges only      |        9 |       55.6 |    883 |   1.55 |          98 |          0.271 |     -808 |        -808 |       692 |
| D V2 + agents (crude) · base              |        7 |       42.9 |  -1219 |   0.35 |        -174 |         -0.538 |    -1219 |        -942 |       522 |
| D V2 + agents (crude) · conservative      |        6 |       16.7 |   -577 |   0.49 |         -96 |         -0.294 |     -615 |        -534 |       455 |

## 2. Full metrics, base fills

|                            |   trades |   wins |   losses |   win_rate |   gross |   charges |    net |     pf |   avg_trade |   expectancy_R |   max_dd |   worst_day |   avg_hold |   avg_win |   avg_loss |   largest_win |   largest_loss |   max_consec_losses |
|:---------------------------|---------:|-------:|---------:|-----------:|--------:|----------:|-------:|-------:|------------:|---------------:|---------:|------------:|-----------:|----------:|-----------:|--------------:|---------------:|--------------------:|
| A current scalper          |       79 |     35 |       44 |       44.3 |   -4508 |      5541 | -10051 |   0.43 |        -127 |         -0.391 |   -11708 |       -1339 |        3.4 |       214 |       -399 |           566 |           -471 |                   4 |
| B V2 strict (spec-literal) |        1 |      1 |        0 |      100   |     115 |        78 |     37 | inf    |          37 |          0.099 |        0 |          37 |        2   |        37 |          0 |            37 |             37 |                   0 |
| C V2 no agents             |        8 |      3 |        5 |       37.5 |    -813 |       594 |  -1405 |   0.32 |        -175 |         -0.53  |    -1405 |        -942 |        4.5 |       217 |       -411 |           578 |           -477 |                   3 |
| D V2 + agents (crude)      |        7 |      3 |        4 |       42.9 |    -699 |       522 |  -1219 |   0.35 |        -174 |         -0.538 |    -1219 |        -942 |        3.7 |       217 |       -467 |           578 |           -477 |                   2 |

## 3. Diagnostics — current scalper (A), base fills

**index × side**

|          |   trades |   win_rate |   pf |   net |   avg_trade |   max_dd |
|:---------|---------:|-----------:|-----:|------:|------------:|---------:|
| NIFTY CE |       40 |       42.5 | 0.39 | -5430 |        -135 |    -7040 |
| NIFTY PE |       39 |       46.2 | 0.47 | -4621 |        -118 |    -5974 |

**CE vs PE**

|    |   trades |   win_rate |   pf |   net |   avg_trade |   max_dd |
|:---|---------:|-----------:|-----:|------:|------------:|---------:|
| CE |       40 |       42.5 | 0.39 | -5430 |        -135 |    -7040 |
| PE |       39 |       46.2 | 0.47 | -4621 |        -118 |    -5974 |

**NIFTY vs SENSEX**

|       |   trades |   win_rate |   pf |    net |   avg_trade |   max_dd |
|:------|---------:|-----------:|-----:|-------:|------------:|---------:|
| NIFTY |       79 |       44.3 | 0.43 | -10051 |        -127 |   -11708 |

**time of day**

|                      |   trades |   win_rate |   pf |   net |   avg_trade |   max_dd |
|:---------------------|---------:|-----------:|-----:|------:|------------:|---------:|
| afternoon (>13:30)   |        7 |       28.6 | 0.27 | -1567 |        -223 |    -1603 |
| midday (11:30–13:30) |       30 |       30   | 0.16 | -6592 |        -219 |    -6592 |
| morning (<11:30)     |       42 |       57.1 | 0.75 | -1892 |         -45 |    -5688 |

**volatility (1-min ATR% vs median)**

|          |   trades |   win_rate |   pf |   net |   avg_trade |   max_dd |
|:---------|---------:|-----------:|-----:|------:|------------:|---------:|
| high vol |       51 |       45.1 | 0.52 | -5262 |        -103 |    -7393 |
| low vol  |       28 |       42.9 | 0.28 | -4789 |        -171 |    -5337 |

**entry type**

|           |   trades |   win_rate |   pf |    net |   avg_trade |   max_dd |
|:----------|---------:|-----------:|-----:|-------:|------------:|---------:|
| ema-cross |       79 |       44.3 | 0.43 | -10051 |        -127 |   -11708 |

**exit reason**

|              |   trades |   win_rate |    pf |    net |   avg_trade |   max_dd |
|:-------------|---------:|-----------:|------:|-------:|------------:|---------:|
| stop at cost |       26 |       84.6 |   1.1 |     60 |           2 |     -445 |
| stop-loss    |       37 |        0   |   0   | -16187 |        -437 |   -16187 |
| target       |       13 |      100   | inf   |   6843 |         526 |        0 |
| time stop    |        3 |        0   |   0   |   -767 |        -255 |     -767 |


## 3. Diagnostics — V2 (C), base fills

**index × side**

|          |   trades |   win_rate |   pf |   net |   avg_trade |   max_dd |
|:---------|---------:|-----------:|-----:|------:|------------:|---------:|
| NIFTY CE |        3 |       33.3 | 0.04 |  -911 |        -303 |     -911 |
| NIFTY PE |        5 |       40   | 0.55 |  -494 |         -98 |     -658 |

**CE vs PE**

|    |   trades |   win_rate |   pf |   net |   avg_trade |   max_dd |
|:---|---------:|-----------:|-----:|------:|------------:|---------:|
| CE |        3 |       33.3 | 0.04 |  -911 |        -303 |     -911 |
| PE |        5 |       40   | 0.55 |  -494 |         -98 |     -658 |

**NIFTY vs SENSEX**

|       |   trades |   win_rate |   pf |   net |   avg_trade |   max_dd |
|:------|---------:|-----------:|-----:|------:|------------:|---------:|
| NIFTY |        8 |       37.5 | 0.32 | -1405 |        -175 |    -1405 |

**time of day**

|                      |   trades |   win_rate |   pf |   net |   avg_trade |   max_dd |
|:---------------------|---------:|-----------:|-----:|------:|------------:|---------:|
| midday (11:30–13:30) |        2 |          0 | 0    |  -947 |        -473 |     -947 |
| morning (<11:30)     |        6 |         50 | 0.59 |  -458 |         -76 |     -658 |

**volatility (1-min ATR% vs median)**

|          |   trades |   win_rate |   pf |   net |   avg_trade |   max_dd |
|:---------|---------:|-----------:|-----:|------:|------------:|---------:|
| high vol |        4 |         50 | 0.11 |  -585 |        -146 |     -658 |
| low vol  |        4 |         25 | 0.41 |  -820 |        -205 |     -928 |

**entry type**

|          |   trades |   win_rate |   pf |   net |   avg_trade |   max_dd |
|:---------|---------:|-----------:|-----:|------:|------------:|---------:|
| pullback |        8 |       37.5 | 0.32 | -1405 |        -175 |    -1405 |

**regime at entry**

|                  |   trades |   win_rate |   pf |   net |   avg_trade |   max_dd |
|:-----------------|---------:|-----------:|-----:|------:|------------:|---------:|
| STRONG_DOWNTREND |        5 |       40   | 0.55 |  -494 |         -98 |     -658 |
| STRONG_UPTREND   |        3 |       33.3 | 0.04 |  -911 |        -303 |     -911 |

**exit reason**

|              |   trades |   win_rate |   pf |   net |   avg_trade |   max_dd |
|:-------------|---------:|-----------:|-----:|------:|------------:|---------:|
| stop at cost |        2 |        100 |  inf |    73 |          36 |        0 |
| stop-loss    |        4 |          0 |    0 | -1870 |        -467 |    -1870 |
| target       |        1 |        100 |  inf |   578 |         578 |        0 |
| time stop    |        1 |          0 |    0 |  -186 |        -186 |     -186 |


## 4. Where the current scalper loses (regime from V2's detector at entry)

|                 |   trades |   win_rate |   pf |   net |   avg_trade |   max_dd |
|:----------------|---------:|-----------:|-----:|------:|------------:|---------:|
| HIGH_VOLATILITY |        2 |       50   | 0.09 |  -420 |        -210 |     -460 |
| RANGE           |       41 |       36.6 | 0.39 | -6115 |        -149 |    -6682 |
| WEAK_DOWNTREND  |       21 |       52.4 | 0.43 | -2460 |        -117 |    -3094 |
| WEAK_UPTREND    |       15 |       53.3 | 0.61 | -1056 |         -70 |    -2576 |

|                         |   trades |   win_rate |   pf |   net |   avg_trade |   max_dd |
|:------------------------|---------:|-----------:|-----:|------:|------------:|---------:|
| NIFTY CE range/high-vol |       25 |       36   | 0.29 | -4374 |        -174 |    -4640 |
| NIFTY CE trend          |       15 |       53.3 | 0.61 | -1056 |         -70 |    -2576 |
| NIFTY PE range/high-vol |       18 |       38.9 | 0.51 | -2161 |        -120 |    -3371 |
| NIFTY PE trend          |       21 |       52.4 | 0.43 | -2460 |        -117 |    -3094 |

|                         |   trades |   win_rate |   pf |   net |   avg_trade |   max_dd |
|:------------------------|---------:|-----------:|-----:|------:|------------:|---------:|
| CE afternoon (>13:30)   |        4 |       25   | 0.43 |  -727 |        -181 |     -841 |
| CE midday (11:30–13:30) |       17 |       29.4 | 0.16 | -3331 |        -195 |    -3331 |
| CE morning (<11:30)     |       19 |       57.9 | 0.63 | -1372 |         -72 |    -3504 |
| PE afternoon (>13:30)   |        3 |       33.3 | 0.04 |  -840 |        -280 |     -876 |
| PE midday (11:30–13:30) |       13 |       30.8 | 0.17 | -3261 |        -250 |    -3413 |
| PE morning (<11:30)     |       23 |       56.5 | 0.87 |  -520 |         -22 |    -2494 |


## 5. Why V2 setups were rejected (base fills, setups with an entry trigger)

| reason                                     |   count |
|:-------------------------------------------|--------:|
| regime not downtrend                       |     430 |
| regime not uptrend                         |     334 |
| too far from VWAP                          |     244 |
| opening range too wide                     |      41 |
| wrong side of VWAP                         |      28 |
| weak/wicky/extended candle                 |      26 |
| score below minimum                        |      13 |
| VIX regime                                 |      12 |
| outside entry window                       |       5 |
| PE side under-performing (needs +10 score) |       4 |
| position already open                      |       1 |


_Runtime 12s. Trades: reports/scalper_v2/trades_*.csv, rejections: rejections_v2.csv._