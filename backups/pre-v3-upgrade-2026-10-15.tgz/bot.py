"""
Nifty / Sensex options bot for Zerodha Kite Connect — strategy v2.

Signal : strategy.signal_v2 on 5-min index candles (trend + momentum + confirmation)
Option : buys an IN-THE-MONEY option (ITM_STRIKES deep), nearest weekly expiry
Exits  : stop / 1:RR target / breakeven trail measured on the INDEX, or square-off
Agents : analysts (fundamental, sentiment, news, technical, crude) → bull/bear debate →
         trader (BUY CE / BUY PE / HOLD) → risk manager (final approval). See agents/pipeline.py.
         Agents can only stop a trade; only the strategy signal can start one.
Safety : daily loss cap, max trades, losses-in-a-row lock, max open positions,
         exchange-side disaster stop in live mode, STOP-file kill switch, limit orders only.

Run via the control panel (app.py), or:  python login.py  then  python bot.py
"""
import csv, json, os, sys, time
from datetime import datetime, date, timedelta
from zoneinfo import ZoneInfo

import config
import strategy
from agents import debate, pipeline, risk_manager, technical, trader

IST = ZoneInfo("Asia/Kolkata")
STATE_FILE = "state.json"
TRADES_FILE = "trades.csv"


def now():
    return datetime.now(IST)


def hm(s):
    h, m = map(int, s.split(":"))
    return now().replace(hour=h, minute=m, second=0, microsecond=0)


def log(*a):
    msg = f"[{now():%H:%M:%S}] " + " ".join(str(x) for x in a)
    print(msg, flush=True)
    with open("bot.log", "a") as f:
        f.write(f"{now():%Y-%m-%d} {msg}\n")


def tick_round(p):
    return round(round(p / 0.05) * 0.05, 2)


# ------------------------------------------------------------------ risk state
class Risk:
    """Persists for the whole day, so restarting the bot does NOT reset limits."""

    def __init__(self):
        self.s = {"date": str(date.today()), "pnl": 0.0, "trades": 0,
                  "consec_losses": 0, "locked": False, "reason": ""}
        if os.path.exists(STATE_FILE):
            with open(STATE_FILE) as f:
                saved = json.load(f)
            if saved.get("date") == self.s["date"]:
                self.s = saved

    def save(self):
        with open(STATE_FILE, "w") as f:
            json.dump(self.s, f, indent=2)

    def record(self, pnl):
        self.s["pnl"] += pnl
        self.s["trades"] += 1
        self.s["consec_losses"] = self.s["consec_losses"] + 1 if pnl < 0 else 0
        if self.s["pnl"] <= -config.MAX_DAILY_LOSS:
            self.lock(f"daily loss limit hit (₹{self.s['pnl']:.0f})")
        elif self.s["consec_losses"] >= config.MAX_CONSECUTIVE_LOSSES:
            self.lock(f"{self.s['consec_losses']} losses in a row")
        elif self.s["trades"] >= config.MAX_TRADES_PER_DAY:
            self.lock("max trades for the day reached")
        self.save()

    def lock(self, reason):
        self.s["locked"], self.s["reason"] = True, reason
        log("RISK LOCK:", reason, "- no more trades today.")
        self.save()

    def can_trade(self):
        return not self.s["locked"]


# ------------------------------------------------------------------ broker
class Broker:
    def __init__(self, kite, live):
        self.kite, self.live = kite, live
        self._instruments = {}

    def ltp(self, key):
        return self.kite.ltp([key])[key]["last_price"]

    def option_for(self, spec, side, spot):
        """Nearest-expiry ITM option for this index."""
        ex = spec["exchange"]
        if ex not in self._instruments:
            self._instruments[ex] = [i for i in self.kite.instruments(ex)
                                     if i["name"] == spec["name"] and i["instrument_type"] in ("CE", "PE")]
        strike = strategy.itm_strike(spot, side, spec["step"], config.ITM_STRIKES)
        today = date.today()
        cands = [i for i in self._instruments[ex]
                 if i["instrument_type"] == side and float(i["strike"]) == strike and i["expiry"] >= today]
        if not cands:
            return None
        return min(cands, key=lambda i: i["expiry"])

    def _wait_fill(self, order_id, timeout=30):
        t0 = time.time()
        while time.time() - t0 < timeout:
            hist = self.kite.order_history(order_id)
            st = hist[-1]["status"]
            if st == "COMPLETE":
                return hist[-1]["average_price"]
            if st in ("REJECTED", "CANCELLED"):
                log("Order", order_id, st, hist[-1].get("status_message"))
                return None
            time.sleep(1)
        try:
            self.kite.cancel_order("regular", order_id)
        except Exception as e:
            log("Cancel failed:", e)
        log("Order not filled in time, cancelled.")
        return None

    def _order(self, ex, sym, side, qty, **kw):
        return self.kite.place_order(variety="regular", exchange=ex, tradingsymbol=sym, transaction_type=side,
                                     quantity=qty, product="MIS", tag=getattr(self, "tag", "kitebot"), **kw)

    def buy(self, ex, sym, qty, ref):
        if not self.live:
            return ref
        oid = self._order(ex, sym, "BUY", qty, order_type="LIMIT", price=tick_round(ref * 1.01))
        return self._wait_fill(oid)

    def move_stop(self, sl_id, trigger):
        """Raise the exchange-side stop (e.g. to cost at 1:1) so it protects the gain if the bot dies."""
        if not self.live or not sl_id:
            return
        try:
            self.kite.modify_order("regular", sl_id, trigger_price=tick_round(trigger),
                                   price=tick_round(trigger * 0.97))
        except Exception as e:
            log("Could not move the exchange stop:", e)

    def disaster_stop(self, ex, sym, qty, trigger):
        """Exchange-side stop far below the bot's own stop — protects you if the bot/PC dies."""
        if not self.live or trigger <= 0.5:
            return None
        return self._order(ex, sym, "SELL", qty, order_type="SL",
                           trigger_price=tick_round(trigger), price=tick_round(trigger * 0.95))

    def sl_filled(self, sl_id):
        if not self.live or not sl_id:
            return None
        h = self.kite.order_history(sl_id)[-1]
        return h["average_price"] if h["status"] == "COMPLETE" else None

    def sell(self, ex, sym, qty, ref, sl_id=None):
        if not self.live:
            return ref
        if sl_id:
            try:
                self.kite.cancel_order("regular", sl_id)
            except Exception as e:
                log("Disaster-stop cancel failed (may already be filled):", e)
                filled = self.sl_filled(sl_id)
                if filled:
                    return filled
        oid = self._order(ex, sym, "SELL", qty, order_type="LIMIT", price=tick_round(ref * 0.98))
        px = self._wait_fill(oid, timeout=20)
        if px is None:
            log("!!! EXIT NOT FILLED for", sym, "- CHECK KITE AND EXIT MANUALLY !!!")
        return px


# ------------------------------------------------------------------ candles
class Candles:
    """Builds OHLC candles from polled prices."""

    def __init__(self, minutes):
        self.m, self.done, self.cur, self.cur_start = minutes, [], None, None

    def bucket(self, t):
        mins = (t.hour * 60 + t.minute) // self.m * self.m
        return t.replace(hour=mins // 60, minute=mins % 60, second=0, microsecond=0)

    def update(self, t, p):
        """Returns True when a candle has just closed."""
        b = self.bucket(t)
        closed = False
        if self.cur_start is not None and b != self.cur_start:
            self.done.append(self.cur)
            self.done = self.done[-400:]
            closed = True
        if self.cur_start != b:
            self.cur_start, self.cur = b, dict(o=p, h=p, l=p, c=p, t=b)
        else:
            self.cur.update(h=max(self.cur["h"], p), l=min(self.cur["l"], p), c=p)
        return closed


def warmup(kite, spec, candles):
    try:
        data = kite.historical_data(spec["token"], now() - timedelta(days=6), now(),
                                    f"{config.CANDLE_MINUTES}minute")
        cur = candles.bucket(now())
        candles.done = [dict(o=c["open"], h=c["high"], l=c["low"], c=c["close"]) for c in data
                        if c["date"].astimezone(IST) < cur][-400:]
        log(f"{spec['name']}: warm-up loaded {len(candles.done)} candles.")
    except Exception as e:
        need = (config.EMA_TREND + 10) * config.CANDLE_MINUTES
        log(f"{spec['name']}: no historical data ({e}). Building live; first signal in ~{need} min.")


def write_status(**kw):
    kw["updated"] = now().strftime("%Y-%m-%d %H:%M:%S")
    kw["mode"] = config.MODE
    tmp = "status.json.tmp"
    with open(tmp, "w") as f:
        json.dump(kw, f, default=str)
    os.replace(tmp, "status.json")


TRADE_COLS = ["date", "mode", "symbol", "qty", "entry_time", "entry", "exit_time", "exit", "pnl", "reason",
              "index", "side", "idx_entry", "idx_sl", "idx_target", "idx_exit", "why"]


def write_trade(row):
    new = not os.path.exists(TRADES_FILE)
    if not new:  # migrate old v1 header if needed
        with open(TRADES_FILE) as f:
            header = f.readline().strip().split(",")
        if header != TRADE_COLS:
            with open(TRADES_FILE) as f:
                old = list(csv.DictReader(f))
            with open(TRADES_FILE, "w", newline="") as f:
                w = csv.DictWriter(f, TRADE_COLS); w.writeheader()
                for r in old:
                    w.writerow({k: r.get(k, "") for k in TRADE_COLS})
    with open(TRADES_FILE, "a", newline="") as f:
        w = csv.DictWriter(f, TRADE_COLS)
        if new:
            w.writeheader()
        w.writerow(row)


# ------------------------------------------------------------------ main loop
def main():
    live = config.MODE == "live"
    for w in config.TIME_WARNINGS:
        log(w)
    if live:
        ok = os.environ.get("BOT_CONFIRM_LIVE") or input("LIVE MODE - real money. Type YES to continue: ")
        if ok.strip() != "YES":
            sys.exit("Aborted.")

    if not live and config.PAPER_FEED == "free":
        from feed import FreeFeed
        kite = FreeFeed()
        log("Paper feed: FREE (Yahoo index prices, modelled option premiums — no Zerodha keys needed)")
    else:
        from kiteconnect import KiteConnect
        kite = KiteConnect(api_key=config.API_KEY)
        with open("access_token.txt") as f:
            kite.set_access_token(f.read().strip())
    broker, risk = Broker(kite, live), Risk()
    names = config.instruments()
    specs = {n: config.INSTRUMENT_SPECS[n] for n in names}
    candles = {n: Candles(config.CANDLE_MINUTES) for n in names}
    log(f"Started v2 in {config.MODE.upper()} mode on {', '.join(names)} | ITM {config.ITM_STRIKES} | "
        f"1:{config.RR:g} | agents on: "
        + (", ".join(k for k, _, flag, _ in pipeline.ANALYSTS if getattr(config, flag)) or "none")
        + f" | trader {'on' if config.USE_TRADER_AGENT else 'off'}")
    for n in names:
        warmup(kite, specs[n], candles[n])

    positions = {}  # name -> dict
    spots = {}
    last_skip = {}

    # agents refresh in a background thread so slow websites never delay exits
    import threading

    def agent_loop():
        while True:
            for e in pipeline.refresh(config):
                log("Agent error:", e)
            time.sleep(60)
    threading.Thread(target=agent_loop, daemon=True).start()

    def close(name, reason, idx_exit):
        p = positions[name]
        px = broker.ltp(p["key"])
        exit_px = broker.sell(p["exchange"], p["sym"], p["qty"], px, p.get("sl_id"))
        if exit_px is None:
            risk.lock("exit order failed - manual check needed")
            return
        pnl = (exit_px - p["entry"]) * p["qty"]
        log(f"EXIT {p['sym']} @ {exit_px:.2f} ({reason}; {name} {idx_exit:.1f}) P&L ₹{pnl:.0f}")
        write_trade(dict(date=date.today(), mode=config.MODE, symbol=p["sym"], qty=p["qty"],
                         entry_time=f"{p['t']:%H:%M}", entry=p["entry"], exit_time=f"{now():%H:%M}",
                         exit=exit_px, pnl=round(pnl, 2), reason=reason, index=name, side=p["side"],
                         idx_entry=round(p["idx_entry"], 2), idx_sl=round(p["sl0"], 2),
                         idx_target=round(p["target"], 2), idx_exit=round(idx_exit, 2), why=p["why"]))
        risk.record(pnl)
        del positions[name]

    while True:
        try:
            t = now()
            if os.path.exists("STOP"):
                log("STOP file found.")
                for n in list(positions):
                    close(n, "kill switch", spots.get(n, 0))
                break
            if t.weekday() >= 5 or t < hm("09:15"):
                write_status(state="waiting for market open", positions=[], spots={}, risk=risk.s,
                             instruments=names)
                time.sleep(30); continue
            if t >= hm(config.SQUARE_OFF_AT):
                for n in list(positions):
                    close(n, "square-off time", broker.ltp(specs[n]["index"]))
                log(f"Day done. P&L ₹{risk.s['pnl']:.0f}, trades {risk.s['trades']}.")
                write_status(state="day finished", positions=[], spots=spots, risk=risk.s, instruments=names)
                break

            for n in names:
                spec = specs[n]
                spot = broker.ltp(spec["index"])
                spots[n] = round(spot, 2)
                new_candle = candles[n].update(t, spot)

                # ---- manage open position on index levels
                if n in positions:
                    p = positions[n]
                    sl_px = broker.sl_filled(p.get("sl_id"))
                    if sl_px:  # disaster stop hit at exchange
                        pnl = (sl_px - p["entry"]) * p["qty"]
                        log(f"DISASTER STOP filled at exchange @ {sl_px:.2f} P&L ₹{pnl:.0f}")
                        write_trade(dict(date=date.today(), mode=config.MODE, symbol=p["sym"], qty=p["qty"],
                                         entry_time=f"{p['t']:%H:%M}", entry=p["entry"], exit_time=f"{t:%H:%M}",
                                         exit=sl_px, pnl=round(pnl, 2), reason="disaster stop", index=n,
                                         side=p["side"], idx_entry=p["idx_entry"], idx_sl=p["sl0"],
                                         idx_target=p["target"], idx_exit=spot, why=p["why"]))
                        risk.record(pnl); del positions[n]
                    else:
                        was_be = p["be_done"]
                        lvl, why = strategy.manage(p, spot, spot, config, now=t, close=spot)
                        if lvl is not None:
                            close(n, why, spot)
                        elif p["be_done"] and not was_be:
                            cost_px = p["entry"] + p["cost_unit"]
                            log(f"{n}: 1:1 reached — stop moved to cost (index {p['sl']:.1f}, "
                                f"option ≈ {cost_px:.2f} incl. charges)")
                            broker.move_stop(p.get("sl_id"), cost_px * 0.98)
                        elif p["be_done"] and config.COST_STOP_ON_PREMIUM:
                            if broker.ltp(p["key"]) <= p["entry"] + p["cost_unit"]:
                                close(n, "stop at cost", spot)

                # ---- new entries on candle close
                if not new_candle or n in positions:
                    continue
                if not (risk.can_trade() and hm(config.NO_ENTRY_BEFORE) <= t <= hm(config.NO_ENTRY_AFTER)):
                    continue
                if len(positions) >= config.MAX_OPEN_POSITIONS:
                    continue
                sig = strategy.signal_v2(candles[n].done, config)
                if not sig:
                    continue
                # ---- agent team: analysts → debate → trader → risk manager
                reports = pipeline.reports(config)
                if config.USE_TECHNICAL_AGENT:  # fresh read on this index's own candles
                    reports["technical"] = technical.analyse(candles[n].done, n.title())
                deb = debate.run(reports, sig["side"])
                dec = trader.decide(sig, deb, config)
                if config.USE_TRADER_AGENT and dec["action"] == "HOLD":
                    log(f"{n}: {sig['side']} signal — trader HOLD: {dec['reason']}")
                    pipeline.record(n, sig, deb, dec, None, "held by trader")
                    continue
                inst = broker.option_for(spec, sig["side"], spot)
                if not inst:
                    log(f"{n}: no ITM option found for {sig['side']}"); continue
                key = f"{spec['exchange']}:{inst['tradingsymbol']}"
                px = broker.ltp(key)
                qty = inst["lot_size"] * config.LOTS
                rm = risk_manager.review(sig, qty, px, risk.s, len(positions), reports.get("crude"),
                                         reports.get("news"), reports.get("fundamental"), config)
                if not rm["approved"]:
                    log(f"{n}: {sig['side']} {inst['tradingsymbol']} vetoed by risk manager — {rm['reason']}")
                    pipeline.record(n, sig, deb, dec, rm, "vetoed by risk manager")
                    continue
                log(f"{n}: trader {dec['action']} (conviction {dec['conviction']:.2f}, debate {deb['margin']:+.2f}); "
                    f"risk manager approved")
                fill = broker.buy(spec["exchange"], inst["tradingsymbol"], qty, px)
                if not fill:
                    pipeline.record(n, sig, deb, dec, rm, "order not filled")
                    continue
                pipeline.record(n, sig, deb, dec, rm, f"bought {inst['tradingsymbol']} x{qty} @ {fill:.2f}")
                # re-anchor index levels to the live spot at fill
                shift = spot - sig["entry"]
                dstop = fill - 1.0 * sig["risk"]  # ITM delta ~0.6-0.7, so this sits well beyond the bot's stop
                positions[n] = dict(sym=inst["tradingsymbol"], key=key, exchange=spec["exchange"], qty=qty,
                                    entry=fill, side=sig["side"], t=t, idx_entry=spot,
                                    sl=sig["sl"] + shift, sl0=sig["sl"] + shift, target=sig["target"] + shift,
                                    risk=sig["risk"], be_done=False, why=sig["why"], best=spot,
                                    cost_pts=strategy.cost_points(fill, qty), cost_unit=strategy.cost_per_unit(fill, qty),
                                    sl_id=broker.disaster_stop(spec["exchange"], inst["tradingsymbol"], qty, dstop))
                p = positions[n]
                log(f"ENTRY {sig['side']} {p['sym']} x{qty} @ {fill:.2f} | {n} {spot:.1f} "
                    f"SL {p['sl']:.1f} TGT {p['target']:.1f} (1:{config.RR:g}) | {sig['why']}")

            # ---- status for dashboard
            plist = []
            for n, p in positions.items():
                ltp = broker.ltp(p["key"])
                plist.append(dict(index=n, symbol=p["sym"], side=p["side"], qty=p["qty"], entry=round(p["entry"], 2),
                                  ltp=ltp, pnl=round((ltp - p["entry"]) * p["qty"], 2), since=p["t"].strftime("%H:%M"),
                                  idx=spots.get(n), idx_sl=round(p["sl"], 1), idx_target=round(p["target"], 1),
                                  breakeven=p["be_done"]))
            write_status(state="running", positions=plist, spots=spots, risk=risk.s, instruments=names,
                         candles={n: len(candles[n].done) for n in names})
            time.sleep(config.POLL_SECONDS)
        except KeyboardInterrupt:
            log("Ctrl+C - stopping.")
            if positions:
                log("!!! Open positions", list(positions), "- exit manually in Kite or rerun bot !!!")
            break
        except Exception as e:
            log("Error:", repr(e))
            time.sleep(10)


if __name__ == "__main__":
    main()
